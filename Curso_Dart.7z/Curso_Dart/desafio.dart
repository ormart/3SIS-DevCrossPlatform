void main(List<String> args) {
  final pacientes = [
    'Rodrigo Rahman|35|Desenvolvedor|SP',
    'Maonoel Silva|12|Estudante|AL',
    'Joaquim Rahman|18|Estudante|SP',
    'Fernando Verne|35|Estudante|PE',
    'Gustavo Silva|40|Desenvolvedor|CE',
    'Sandra Silva|40|Desenvolvedor|MG',
    'Regina Verne|35|Dentista|MG',
    'João Rahman|55|Jornalista|RJ'
  ];
//Baseado no array acima monte um relatorio onde:
//1 - Inclua o nome, idade, profissao e estado de origem dos participantes do grupo no array;
//2 - Apresente a quantidade total de pacientes do array;
//1 = Apresente os pacientes com mais de 20 anos e print o nome deles;
//2 - Apresente quantos pacientes existem para cada profissao(dev, estudante, dentista, jornalista);
//3 - Apresente a quantidade de pacientes que moram em sp;

print('A quantidade de pacientes é:${pacientes.length}');

}