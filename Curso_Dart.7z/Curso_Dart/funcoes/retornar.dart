int Function(int) somaParcial(int a) {
  int c = 0;
  return (int b) {
    return a + b + c;
  };
}

void main(List<String> args) {
  print(somaParcial(2)(10));
}
