void main(List<String> args) {
  var alunos = [
    {'nome': 'Alfredo', 'nota': 9.9},
    {'nome': 'Wilson', 'nota': 9.3},
    {'nome': 'Mariana', 'nota': 8.7},
    {'nome': 'Ana', 'nota': 7.6},
    {'nome': 'Ricardo', 'nota': 6.8},
  ];
  
  var total = alunos
      .map((aluno) => aluno['nota'])
      .map((nota) => (nota as double))
      .reduce((t, a) => t + a);

  print(total);

  var somaNotas = 0.0;
  for (var aluno in alunos) {
    somaNotas += aluno['nota'] as double;
  }
  var media = somaNotas / alunos.length;
  print('A média das notas dos alunos é: ${media.toStringAsFixed(2)}');
  
  print("O valor da média é: ${total/alunos.length}");
}
